# StudioPilot AI Video Studio

A free-first, responsive YouTube video planning workspace for mobile and desktop.

## What works in this version
- Create and save a project in the current browser (localStorage).
- Topic idea generation using local fallback templates.
- Optional AI text generation through a Netlify serverless function.
- Manual approval gates for topic, script, storyboard and publish pack.
- Script editor and word count.
- Storyboard scene cards that can be edited, added and removed.
- Local media file selection (files are not uploaded).
- Edit decision list (EDL) generation and download.
- YouTube metadata draft and project JSON export.
- Responsive dark interface.

## What is not connected
This version does NOT generate video files, synthesize voice audio, render/assemble MP4, scrape private or live competitor analytics, download third-party videos, or upload directly to YouTube. It does not claim that selecting media creates a rendered video. Those require separate providers, processing infrastructure, permissions and sometimes paid credits.

## Deploy on Netlify (GitHub + Chrome)
1. Extract the ZIP.
2. Create a GitHub repository and upload all extracted files, keeping the folder structure.
3. In Netlify choose **Add new site → Import an existing project** and connect the repository.
4. Build command: leave blank. Publish directory: `.` (dot).
5. Deploy. The site works with local fallback mode without an API key.

## Optional AI text generation
1. Create an OpenRouter API key yourself and check its current pricing/free model availability before using it.
2. In Netlify: **Site configuration → Environment variables**.
3. Add `OPENROUTER_API_KEY` with your secret key. Optionally add `OPENROUTER_MODEL` with a model supported by your account.
4. Redeploy the site.
5. Open StudioPilot → Settings → Test AI connection.

Never put the API key in `index.html`, GitHub source, or a public message. API model availability, pricing and free quotas can change.

## Local preview
Open `index.html` in a modern browser. AI calls will not work locally unless the Netlify function is deployed; local fallback templates still work.

## Data note
Project data is stored in the browser's localStorage. Export project JSON regularly as a backup. Clearing browser storage can delete the project.
